const authorsList = document.querySelector("#authors-list");
const biblioItems = document.querySelectorAll(".biblio-item");
const yearHeaders = document.querySelectorAll(".year-header");
let selectedAuthors = [];
let coauthorElements = new Map();

function filterPublications() {
  biblioItems.forEach((item) => {
    const authors = item.dataset.authors.split(" and ");
    item.hidden = !selectedAuthors.every((author) => authors.includes(author));
  });
}

function getCoauthorsFromPublications() {
  const coauthors = new Map();
  biblioItems.forEach((item) => {
    const authors = item.dataset.authors.split(" and ");
    authors.forEach((author) => {
      coauthors.set(author, (coauthors.get(author) ?? 0) + 1);
    });
  });
  coauthors.delete("Dallard, Clément");
  const sortedCoauthors = Array.from(coauthors.keys()).sort((a, b) => {
    // Normalize the strings to lowercase for case-insensitive comparison
    a = a.toLowerCase();
    b = b.toLowerCase();

    // Normalize UTF-8/16 characters to ASCII equivalents
    a = a.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    b = b.normalize("NFD").replace(/[\u0300-\u036f]/g, "");

    // Compare the strings normally
    if (a < b) {
      return -1;
    } else if (a > b) {
      return 1;
    } else {
      return 0;
    }
  });
  return { sortedCoauthors, coauthors };
}

function filterAuthors() {
  const displayedAuthors = new Map();
  const displayedPublications = document.querySelectorAll(
    ".biblio-item:not([hidden])"
  );

  displayedPublications.forEach((pub) => {
    const authors = pub.dataset.authors.split(" and ");
    authors.forEach((author) =>
      displayedAuthors.set(author, (displayedAuthors.get(author) ?? 0) + 1)
    );
  });
  displayedAuthors.delete("Dallard, Clément");

  console.log(displayedAuthors.size + " " + displayedPublications.length);

  const { sortedCoauthors, coauthors } = getCoauthorsFromPublications(
    displayedPublications
  );

  sortedCoauthors.forEach((author) => {
    let li = coauthorElements.get(author);

    if (!li) {
      li = document.createElement("li");
      const a = document.createElement("a");
      a.href = "#";
      a.classList.add("author-link");
      a.dataset.filter = author;
      li.appendChild(a);
      authorsList.appendChild(li);
      coauthorElements.set(author, li);
    }

    li.querySelector("a").textContent = `${author} (${displayedAuthors.get(
      author
    )})`;
    li.hidden = !displayedAuthors.has(author);

    if (selectedAuthors.includes(author)) {
      li.querySelector("a").classList.add("selected");
    } else {
      li.querySelector("a").classList.remove("selected");
    }
  });

  const clearAllLink = authorsList.querySelector(".clear-all-link");
  if (selectedAuthors.length > 0) {
    clearAllLink.innerHTML = '<a href="#">(Clear selection)</a>';
  } else {
    clearAllLink.textContent = "(Select co-authors)";
  }
  clearAllLink.hidden = displayedAuthors.size === 0;
}

function filterYears() {
  yearHeaders.forEach((header) => {
    const year = header.textContent.trim();
    const yearPublications = document.querySelectorAll(
      `.biblio-item[data-year="${year}"]`
    );
    const displayedPublications = document.querySelectorAll(
      `.biblio-item[data-year="${year}"]:not([hidden])`
    );
    header.hidden = displayedPublications.length === 0;
    const bibliography = header.nextElementSibling;
    if (header.hidden) {
      bibliography.hidden = true;
    } else {
      bibliography.hidden = false;
    }
  });
}

authorsList.addEventListener("click", (event) => {
  const clickedLink = event.target.closest("a");
  if (!clickedLink) {
    return;
  }

  if (clickedLink.parentNode.classList.contains("clear-all-link")) {
    selectedAuthors = [];
  } else {
    const authorName = clickedLink.dataset.filter;
    if (selectedAuthors.includes(authorName)) {
      selectedAuthors = selectedAuthors.filter((name) => name !== authorName);
    } else {
      selectedAuthors.push(authorName);
    }
  }

  filterPublications();
  filterAuthors();
  filterYears();
});

filterPublications();
filterAuthors();
filterYears();
