// Get all the co-author links
const authorLinks = Array.from(document.querySelectorAll('.author-link'));

// Get all the publication items
const publicationItems = Array.from(document.querySelectorAll('.biblio-item'));

// Create an object to store the co-authors and their publications
const coauthors = {};

// Loop through the co-authors in the YAML file and populate the object
{% for coauthor in site.data.co-authors.co-authors %}
coauthors["{{ coauthor.name }}"] = {{ coauthor.publications | jsonify }};
{% endfor %}

// Add click event listeners to the co-author links
authorLinks.forEach((link) => {
  link.addEventListener('click', () => {
    link.classList.toggle('active');
    const selectedAuthors = Array.from(document.querySelectorAll('.author-link.active'), ({dataset: { filter }}) => filter);

    if (selectedAuthors.length === 0) {
      publicationItems.forEach((item) => {
        if (item.style.display !== 'grid') item.style.display = 'grid';
      });
      authorLinks.forEach((link) => {
        if (link.style.display !== 'block') link.style.display = 'block';
      });
    } else {
      publicationItems.forEach((item) => {
        const displayStyle = selectedAuthors.every((author) => coauthors[author].includes(item.id)) ? 'grid' : 'none';
        if (item.style.display !== displayStyle) item.style.display = displayStyle;
      });
      authorLinks.forEach((link) => {
        const displayStyle = selectedAuthors.includes(link.dataset.filter) ? 'block' : 'none';
        if (link.style.display !== displayStyle) link.style.display = displayStyle;
      });
    }

    const visiblePublications = publicationItems.filter((item) => item.style.display !== 'none');
    const visibleCoauthors = Object.keys(coauthors).filter((author) => visiblePublications.some((item) => coauthors[author].includes(item.id)));
    authorLinks.forEach((link) => {
      const displayStyle = visibleCoauthors.includes(link.dataset.filter) ? 'block' : 'none';
      if (link.style.display !== displayStyle) link.style.display = displayStyle;
    });
    
    const yearHeaders = Array.from(document.querySelectorAll('#publications h2.year-header'));
    yearHeaders.forEach((header) => {
      header.style.display = 'none';
    });

    visiblePublications.forEach((pub) => {
      const pubYear = pub.dataset.year;
      const yearHeader = Array.from(document.querySelectorAll('#publications h2')).find((header) => header.textContent === pubYear);
      if (yearHeader) yearHeader.style.display = 'block';
    });
  });
});

// Add click event listener to the "clear all" link
const clearAllLink = document.querySelector('.clear-all-link a');
clearAllLink.addEventListener('click', () => {
  authorLinks.forEach((link) => {
    if (link.classList.contains('active')) link.classList.remove('active');
    if (link.style.display !== 'block') link.style.display = 'block';
  });
  publicationItems.forEach((item) => {
    if (item.style.display !== 'grid') item.style.display = 'grid';
  });
  const yearHeaders = Array.from(document.querySelectorAll('#publications h2'));
  yearHeaders.forEach((heading) => {
    if (heading.style.display !== 'block') heading.style.display = 'block';
  });
});

const yearHeaders = Array.from(document.querySelectorAll('#publications h2'));
yearHeaders.forEach((header) => header.style.display = 'block');